﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackendPr.Entidades.entities
{
    public class Validar
    {
        public string usuario {  get; set; }
        public string contrasena { get; set; }
    }
}
