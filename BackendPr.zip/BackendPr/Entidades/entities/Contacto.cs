﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackendPr.Entidades
{
    public class Contacto
    {
        public string nombre { get; set; }

        public string email { get; set; }

        public string telefono { get; set; }

        public string mensaje { get; set; }

        public string direccion { get; set; }

    }
}
