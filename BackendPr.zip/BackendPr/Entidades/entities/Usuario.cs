﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Usuario
    {
        public string NombreCompleto { get; set; }
        public string usuario { get; set; }
        public string Contrasena { get; set; }
        public string Email { get; set; }

    }
}

