﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackendPr.Entidades.Request
{
    public class ReqInsertarReserva
    {
        public Reservas Reservas { get; set; }
    }
}
